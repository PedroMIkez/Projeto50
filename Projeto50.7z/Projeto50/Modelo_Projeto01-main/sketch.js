var bg, bgImg, shooter, shooterImg, shooterShoting, shooterShotingImg, shooterLEFTImg, shooterShotingLEFTImg;
var gameState=1
var zumbi, zumbiImg, zumbi2Img;
var bullet;

function preload(){
 bgImg = loadImage("bg2.png");
 shooterImg = loadImage("shooter_2.png"); 
 shooterShotingImg = loadImage("shooter_3.png");
 shooterLEFTImg = loadImage("shooter_LEFT.png");
 shooterShotingLEFTImg = loadImage("shooter_3LEFT.png");
 zumbiImg = loadAnimation("Walk1.png","Walk2.png","Walk3.png","Walk4.png","Walk5.png","Walk6.png");
 zumbi2Img = loadAnimation("Dead3.png","Dead4.png","Dead5.png","Dead6.png","Dead7.png","Dead8.png");
}

function setup() {
 createCanvas(1300,650);
  
  //adicionando a imagem de fundo
  bg = createSprite(660,450,30,30);
  bg.addImage(bgImg);
  bg.scale = 0.5

  // adicionando jogador
  shooter = createSprite(560,450,30,30);
  shooter.addImage(shooterImg);
  shooter.scale = 0.5;

  //adicionando imagem de atirar
  shooterShoting = createSprite(560,450,30,30)
  shooterShoting.addImage(shooterShotingImg);
  shooterShoting.visible = false;
  shooterShoting.scale = 0.5;

 //grupos
 zumbiGroup = createGroup();
 bulletGroup = createGroup(); 

 

}

function draw() {
  background(0);
  
  //colisão nas bordas do jogo
  edges = createEdgeSprites();
  shooter.collide(edges);
  shooterShoting.collide(edges);

 
  //play
  if (gameState===1){
    shooter.visible = true
    shooterShoting.visible = false

    if (frameCount % 190 === 0) {
      drawZumbi();
    }

  //mover jogador para baixo 
  if (keyDown("S")){
    shooter.y +=10
    shooterShoting.y +=10
  }
  // mover jogador para cima
  if (keyDown("W")){
    shooter.y -=10
    shooterShoting.y -=10
  }

  // mover jogador para direita
  if (keyDown("D")){
    shooter.x +=10
    shooterShoting.x +=10
    shooter.addImage(shooterImg);
    shooterShoting.addImage(shooterShotingImg);

  }
  // mover jogador para esquerda
  if (keyDown("A")){
    shooter.x -=10
    shooterShoting.x -=10
    shooter.addImage(shooterLEFTImg);
    shooterShoting.addImage(shooterShotingLEFTImg);
  }
   // apertar o espaço para atirar
  if (keyDown("space")){
    Shoting();
  }

  if (bulletGroup.collide(zumbiGroup)){
    Death();
    bulletGroup.destroyEach();
  }

  


  drawSprites();
}

}
//função para atirar
function Shoting(){
shooterShoting.visible = true
shooter.visible = false
gameState=1;

bullet= createSprite(450, width/-2, 50,20)
bullet.y= shooter.y+10
bullet.x= shooter.x-10
bullet.x= shooter.x+10
bullet.scale=0.2
bullet.velocityX= -80
bulletGroup.add(bullet)
}
// zumbis aleatorios/ordas de zumbis
function drawZumbi(){
  zumbi = createSprite(-100,random(510,200),40,40);
  zumbi.addAnimation("walk",zumbiImg);
  zumbi.scale = 0.5;
  zumbi.lifetime = 2000;
  zumbi.velocityX = +1
  zumbiGroup.add(zumbi);
}

function Death(){
  zumbi.addAnimation("death1",zumbi2Img);
  zumbi.velocityX = 0;
  zumbi.lifetime = 50;
}

